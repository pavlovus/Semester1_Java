import stanford.karel.SuperKarel;


public class Task2 extends SuperKarel{

	public void run(){
		for(int i=0; i<9; i++){
			if(facingEast()){
				findLeftPass();
			} else {
				findRightPass();
			}
		}
	}
	private void findLeftPass(){
		while (leftIsBlocked()){
			if(frontIsClear()){
				move();
			}
		}
		turnLeft();
		checkFront();
		goUp();
		if(leftIsBlocked()){
			turnRight();
		}
		else {
			turnLeft();
		}
	}
	private void findRightPass(){
		while (rightIsBlocked()){
			if(frontIsClear()){
				move();
			} else {
				turnAround();
				findLeftPass();
				break;
				}
		}
		turnRight();
		checkFront();
		goUp();
		if(frontIsBlocked()){
			turnLeft();
		} else {
				turnRight();
			}
	}
	private void checkFront(){
		if (frontIsClear()){
			move();
		}
	}
	private void goUp(){
		while(frontIsClear()){
			move();
		}
	}
}